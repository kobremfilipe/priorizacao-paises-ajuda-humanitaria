# Priorização de Países para Ajuda Humanitária

Projeto de Ciência de Dados que utiliza análise exploratória, tratamento de dados e técnicas de clustering para identificar perfis de vulnerabilidade socioeconômica e de saúde em 167 países. O objetivo é apoiar a discussão sobre priorização de recursos humanitários — não produzir uma classificação definitiva da necessidade de cada país.

## Objetivos

- Explorar a qualidade dos dados e identificar valores ausentes, inválidos e outliers.
- Tratar valores inválidos e imputar dados ausentes com KNN.
- Investigar correlações e selecionar indicadores complementares.
- Aplicar K-Means e agrupamento hierárquico pelo método de Ward.
- Comparar os agrupamentos e avaliar a sensibilidade dos resultados.
- Interpretar os grupos para apoiar uma estratégia de priorização humanitária.

## Dados e indicadores

A base contém 167 países e 18 variáveis. Para o clustering final foram selecionados quatro indicadores:

- Mortalidade infantil
- PIB per capita
- Acesso à água
- Gastos com saúde (% do PIB)

O país é mantido como identificador para interpretação, mas não é utilizado como variável de clustering.

## Metodologia

1. Exploração inicial e diagnóstico da qualidade dos dados.
2. Conversão do código `99999` e de valores logicamente inválidos para valores ausentes.
3. Identificação de outliers pelo intervalo interquartil (IQR), preservando extremos estatísticos plausíveis.
4. Imputação com `KNNImputer` (`k=5`), com padronização antes da imputação.
5. Análise de correlação e seleção dos quatro indicadores.
6. Padronização Z-score e uso da distância Euclidiana.
7. Avaliação de diferentes valores de `k` pelo método do cotovelo, Silhouette Score e interpretabilidade.
8. Comparação entre K-Means e agrupamento hierárquico de Ward, incluindo Adjusted Rand Index (ARI).
9. Análise de sensibilidade com transformação logarítmica do PIB per capita.

## Principais resultados

- Foram escolhidos **3 clusters** para o K-Means; o Silhouette Score foi **0,4064**.
- O **Cluster 1** apresentou o perfil médio de maior vulnerabilidade: mortalidade infantil mais elevada, PIB per capita mais baixo e menor acesso à água.
- A comparação entre K-Means e Ward apresentou **ARI de 0,580**, com 48 dos 50 países do cluster prioritário permanecendo juntos no agrupamento hierárquico.
- A transformação logarítmica do PIB foi testada, mas não adotada porque reduziu o Silhouette e a concordância entre os métodos.

Os resultados são relativos aos indicadores disponíveis. Conflitos, desastres, deslocamentos populacionais, crises sanitárias e capacidade local de resposta também devem ser considerados em decisões operacionais reais.

## Estrutura do repositório

```text
priorizacao-paises-ajuda-humanitaria/
├── analise_priorizacao_paises.ipynb
├── paises_help_international.csv
├── relatorio_tecnico.docx
├── requirements.txt
├── .gitignore
└── README.md
```

## Como executar

1. Clone ou baixe este repositório.
2. Instale as dependências:

   ```bash
   pip install -r requirements.txt
   ```

3. Abra `analise_priorizacao_paises.ipynb` no Jupyter Notebook, JupyterLab ou VS Code.
4. Execute as células na ordem apresentada. O CSV deve permanecer na mesma pasta do notebook.

## Tecnologias

Python · pandas · NumPy · Matplotlib · scikit-learn · SciPy · Jupyter Notebook · K-Means · KNN Imputer · Clustering hierárquico

## Arquivos

- `analise_priorizacao_paises.ipynb`: código, análises e visualizações.
- `paises_help_international.csv`: base de dados utilizada.
- `relatorio_tecnico.docx`: relatório técnico completo.

## Observação sobre os dados

Antes de tornar o repositório público, confirme que a licença ou os termos da fonte original permitem redistribuir o arquivo CSV. Caso não permitam, remova o CSV do repositório e documente no README como obter a base de forma legítima.
